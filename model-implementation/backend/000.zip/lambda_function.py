import json
import pandas as pd
import boto3
import uuid

def sendsqs(message):
    sqs = boto3.client('sqs')
    queue_url = 'https://sqs.us-west-2.amazonaws.com/488951004301/sqs-002.fifo'

    response = sqs.send_message(
        QueueUrl=queue_url,
        MessageBody=str(message),
        MessageGroupId='message_group',
        MessageDeduplicationId=str(uuid.uuid4())
    )

def lambda_handler(event, context):
    postal_conv = pd.read_csv("postal_long_lat.csv")
    string = [1, 2, 3, 4, 5, 'V6L1M5']
    # string = event['X-input']
    po = string[-1]
    temp = postal_conv[postal_conv['Postal code'] == po]
    if len(temp) == 0:
        return {
            'statusCode': 404,
            'body': json.dumps('Postal code not valid')
        }
    else:
        long = temp.iloc[0]['LONG']
        lat = temp.iloc[0]['LAT']
        print(long, lat)
    string.append(long)
    string.append(lat)
    sendsqs(string)


    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
